#ifndef __uI45rXB9AeVXt54lptAQyC_h__
#define __uI45rXB9AeVXt54lptAQyC_h__

/* Include files */
#include "simstruc.h"
#include "rtwtypes.h"
#include "multiword_types.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_simstruct_bridge.h"
#include "sl_sfcn_cov/sl_sfcn_cov_bridge.h"

/* Type Definitions */
#include <time.h>
#include <time.h>
#ifndef struct_tag_yXNlxAMtkozv4BiPFKvBVC
#define struct_tag_yXNlxAMtkozv4BiPFKvBVC

struct tag_yXNlxAMtkozv4BiPFKvBVC
{
  boolean_T f1;
};

#endif                                 /* struct_tag_yXNlxAMtkozv4BiPFKvBVC */

#ifndef typedef_s_yXNlxAMtkozv4BiPFKvBVC
#define typedef_s_yXNlxAMtkozv4BiPFKvBVC

typedef struct tag_yXNlxAMtkozv4BiPFKvBVC s_yXNlxAMtkozv4BiPFKvBVC;

#endif                                 /* typedef_s_yXNlxAMtkozv4BiPFKvBVC */

#ifndef struct_tag_IXZbk4aPjQFR6fO0q1hmvH
#define struct_tag_IXZbk4aPjQFR6fO0q1hmvH

struct tag_IXZbk4aPjQFR6fO0q1hmvH
{
  int32_T __dummy;
};

#endif                                 /* struct_tag_IXZbk4aPjQFR6fO0q1hmvH */

#ifndef typedef_comm_internal_AWGNChannel_2
#define typedef_comm_internal_AWGNChannel_2

typedef struct tag_IXZbk4aPjQFR6fO0q1hmvH comm_internal_AWGNChannel_2;

#endif                                 /* typedef_comm_internal_AWGNChannel_2 */

#ifndef struct_tag_DuJTIxHyPH0sh2f3wcGFk
#define struct_tag_DuJTIxHyPH0sh2f3wcGFk

struct tag_DuJTIxHyPH0sh2f3wcGFk
{
  s_yXNlxAMtkozv4BiPFKvBVC _data;
};

#endif                                 /* struct_tag_DuJTIxHyPH0sh2f3wcGFk */

#ifndef typedef_s_DuJTIxHyPH0sh2f3wcGFk
#define typedef_s_DuJTIxHyPH0sh2f3wcGFk

typedef struct tag_DuJTIxHyPH0sh2f3wcGFk s_DuJTIxHyPH0sh2f3wcGFk;

#endif                                 /* typedef_s_DuJTIxHyPH0sh2f3wcGFk */

#ifndef struct_tag_BlgwLpgj2bjudmbmVKWwDE
#define struct_tag_BlgwLpgj2bjudmbmVKWwDE

struct tag_BlgwLpgj2bjudmbmVKWwDE
{
  uint32_T f1[8];
};

#endif                                 /* struct_tag_BlgwLpgj2bjudmbmVKWwDE */

#ifndef typedef_cell_wrap
#define typedef_cell_wrap

typedef struct tag_BlgwLpgj2bjudmbmVKWwDE cell_wrap;

#endif                                 /* typedef_cell_wrap */

#ifndef struct_tag_qFrJMUUocJZmRjoThTGw9E
#define struct_tag_qFrJMUUocJZmRjoThTGw9E

struct tag_qFrJMUUocJZmRjoThTGw9E
{
  int32_T isInitialized;
  boolean_T TunablePropsChanged;
  cell_wrap inputVarSize[1];
  real_T EbNo;
  real_T SignalPower;
  real_T pFirstInputNumChan;
  boolean_T pIsVarChannel;
  real_T pNumChanFromProp;
  real_T pStd;
  real_T Seed;
};

#endif                                 /* struct_tag_qFrJMUUocJZmRjoThTGw9E */

#ifndef typedef_comm_internal_AWGNChannel
#define typedef_comm_internal_AWGNChannel

typedef struct tag_qFrJMUUocJZmRjoThTGw9E comm_internal_AWGNChannel;

#endif                                 /* typedef_comm_internal_AWGNChannel */

#ifndef struct_tag_s7x1Wx46WFovLWMRmX2SU0C
#define struct_tag_s7x1Wx46WFovLWMRmX2SU0C

struct tag_s7x1Wx46WFovLWMRmX2SU0C
{
  char_T struct_tm[7];
  char_T struct_timespec[13];
};

#endif                                 /* struct_tag_s7x1Wx46WFovLWMRmX2SU0C */

#ifndef typedef_s7x1Wx46WFovLWMRmX2SU0C
#define typedef_s7x1Wx46WFovLWMRmX2SU0C

typedef struct tag_s7x1Wx46WFovLWMRmX2SU0C s7x1Wx46WFovLWMRmX2SU0C;

#endif                                 /* typedef_s7x1Wx46WFovLWMRmX2SU0C */

#ifndef struct_tag_Mq55LRTpx3F49SLl4MgJ3G
#define struct_tag_Mq55LRTpx3F49SLl4MgJ3G

struct tag_Mq55LRTpx3F49SLl4MgJ3G
{
  real_T f1[2];
};

#endif                                 /* struct_tag_Mq55LRTpx3F49SLl4MgJ3G */

#ifndef typedef_b_cell_wrap
#define typedef_b_cell_wrap

typedef struct tag_Mq55LRTpx3F49SLl4MgJ3G b_cell_wrap;

#endif                                 /* typedef_b_cell_wrap */

#ifndef struct_tag_iausgUa9Tcm9fmfau0mSIH
#define struct_tag_iausgUa9Tcm9fmfau0mSIH

struct tag_iausgUa9Tcm9fmfau0mSIH
{
  char_T Value[6];
};

#endif                                 /* struct_tag_iausgUa9Tcm9fmfau0mSIH */

#ifndef typedef_s_iausgUa9Tcm9fmfau0mSIH
#define typedef_s_iausgUa9Tcm9fmfau0mSIH

typedef struct tag_iausgUa9Tcm9fmfau0mSIH s_iausgUa9Tcm9fmfau0mSIH;

#endif                                 /* typedef_s_iausgUa9Tcm9fmfau0mSIH */

#ifndef struct_tag_L5JvjW1A13FyCQi5N783sB
#define struct_tag_L5JvjW1A13FyCQi5N783sB

struct tag_L5JvjW1A13FyCQi5N783sB
{
  char_T f1[7];
};

#endif                                 /* struct_tag_L5JvjW1A13FyCQi5N783sB */

#ifndef typedef_c_cell_wrap
#define typedef_c_cell_wrap

typedef struct tag_L5JvjW1A13FyCQi5N783sB c_cell_wrap;

#endif                                 /* typedef_c_cell_wrap */

#ifndef struct_tag_C79ocpswzft4rqJBIhLBlC
#define struct_tag_C79ocpswzft4rqJBIhLBlC

struct tag_C79ocpswzft4rqJBIhLBlC
{
  char_T f1[4];
  char_T f2[3];
  char_T f3[6];
};

#endif                                 /* struct_tag_C79ocpswzft4rqJBIhLBlC */

#ifndef typedef_cell
#define typedef_cell

typedef struct tag_C79ocpswzft4rqJBIhLBlC cell;

#endif                                 /* typedef_cell */

#ifndef struct_tag_ueapjuTygbhlYTyuwuM18F
#define struct_tag_ueapjuTygbhlYTyuwuM18F

struct tag_ueapjuTygbhlYTyuwuM18F
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[7];
  char_T f4[3];
  char_T f5[6];
  char_T f6[6];
};

#endif                                 /* struct_tag_ueapjuTygbhlYTyuwuM18F */

#ifndef typedef_b_cell
#define typedef_b_cell

typedef struct tag_ueapjuTygbhlYTyuwuM18F b_cell;

#endif                                 /* typedef_b_cell */

#ifndef struct_tag_IWHquoku2Gpg6ovlO02R9F
#define struct_tag_IWHquoku2Gpg6ovlO02R9F

struct tag_IWHquoku2Gpg6ovlO02R9F
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[3];
  char_T f4[6];
  char_T f5[6];
};

#endif                                 /* struct_tag_IWHquoku2Gpg6ovlO02R9F */

#ifndef typedef_c_cell
#define typedef_c_cell

typedef struct tag_IWHquoku2Gpg6ovlO02R9F c_cell;

#endif                                 /* typedef_c_cell */

#ifndef struct_tag_xR7dlhZdUObjGfdDSjt5XE
#define struct_tag_xR7dlhZdUObjGfdDSjt5XE

struct tag_xR7dlhZdUObjGfdDSjt5XE
{
  char_T f1[4];
  char_T f2[8];
  char_T f3[3];
  char_T f4[6];
  char_T f5[7];
};

#endif                                 /* struct_tag_xR7dlhZdUObjGfdDSjt5XE */

#ifndef typedef_d_cell
#define typedef_d_cell

typedef struct tag_xR7dlhZdUObjGfdDSjt5XE d_cell;

#endif                                 /* typedef_d_cell */

#ifndef struct_tag_Hm6EPE5ncyWd4RGCxxctzF
#define struct_tag_Hm6EPE5ncyWd4RGCxxctzF

struct tag_Hm6EPE5ncyWd4RGCxxctzF
{
  char_T f1[30];
  char_T f2[29];
  char_T f3[30];
  char_T f4[30];
  char_T f5[39];
};

#endif                                 /* struct_tag_Hm6EPE5ncyWd4RGCxxctzF */

#ifndef typedef_e_cell
#define typedef_e_cell

typedef struct tag_Hm6EPE5ncyWd4RGCxxctzF e_cell;

#endif                                 /* typedef_e_cell */

#ifndef struct_tag_ge1UD3YqHcNerzgtJ4AjXF
#define struct_tag_ge1UD3YqHcNerzgtJ4AjXF

struct tag_ge1UD3YqHcNerzgtJ4AjXF
{
  char_T f1[6];
};

#endif                                 /* struct_tag_ge1UD3YqHcNerzgtJ4AjXF */

#ifndef typedef_d_cell_wrap
#define typedef_d_cell_wrap

typedef struct tag_ge1UD3YqHcNerzgtJ4AjXF d_cell_wrap;

#endif                                 /* typedef_d_cell_wrap */

#ifndef struct_tag_n5V6NPhGd1s3l2q7z9eOR
#define struct_tag_n5V6NPhGd1s3l2q7z9eOR

struct tag_n5V6NPhGd1s3l2q7z9eOR
{
  char_T f1[27];
  char_T f2[21];
  char_T f3[26];
};

#endif                                 /* struct_tag_n5V6NPhGd1s3l2q7z9eOR */

#ifndef typedef_f_cell
#define typedef_f_cell

typedef struct tag_n5V6NPhGd1s3l2q7z9eOR f_cell;

#endif                                 /* typedef_f_cell */

#ifndef struct_tag_VqK0uXiUXuliBvHmvcLR0F
#define struct_tag_VqK0uXiUXuliBvHmvcLR0F

struct tag_VqK0uXiUXuliBvHmvcLR0F
{
  char_T f1[28];
  char_T f2[22];
  char_T f3[35];
  char_T f4[26];
  char_T f5[36];
  char_T f6[39];
};

#endif                                 /* struct_tag_VqK0uXiUXuliBvHmvcLR0F */

#ifndef typedef_g_cell
#define typedef_g_cell

typedef struct tag_VqK0uXiUXuliBvHmvcLR0F g_cell;

#endif                                 /* typedef_g_cell */

#ifndef struct_tag_fBlGzRSC7MIhHBr5b4VWCG
#define struct_tag_fBlGzRSC7MIhHBr5b4VWCG

struct tag_fBlGzRSC7MIhHBr5b4VWCG
{
  char_T f1[6];
  char_T f2[6];
  char_T f3[11];
};

#endif                                 /* struct_tag_fBlGzRSC7MIhHBr5b4VWCG */

#ifndef typedef_h_cell
#define typedef_h_cell

typedef struct tag_fBlGzRSC7MIhHBr5b4VWCG h_cell;

#endif                                 /* typedef_h_cell */

#ifndef struct_tag_QUrJGLT4DsCLhnuPIs5e8F
#define struct_tag_QUrJGLT4DsCLhnuPIs5e8F

struct tag_QUrJGLT4DsCLhnuPIs5e8F
{
  char_T f1[2];
};

#endif                                 /* struct_tag_QUrJGLT4DsCLhnuPIs5e8F */

#ifndef typedef_e_cell_wrap
#define typedef_e_cell_wrap

typedef struct tag_QUrJGLT4DsCLhnuPIs5e8F e_cell_wrap;

#endif                                 /* typedef_e_cell_wrap */

#ifndef struct_tag_KzvDXcILqv8HZzd4pSVRPG
#define struct_tag_KzvDXcILqv8HZzd4pSVRPG

struct tag_KzvDXcILqv8HZzd4pSVRPG
{
  char_T f1[4];
  char_T f2[6];
  char_T f3[7];
  char_T f4[11];
  char_T f5[6];
};

#endif                                 /* struct_tag_KzvDXcILqv8HZzd4pSVRPG */

#ifndef typedef_i_cell
#define typedef_i_cell

typedef struct tag_KzvDXcILqv8HZzd4pSVRPG i_cell;

#endif                                 /* typedef_i_cell */

#ifndef struct_tag_fxrtQpZcildDTGvn3QeHJH
#define struct_tag_fxrtQpZcildDTGvn3QeHJH

struct tag_fxrtQpZcildDTGvn3QeHJH
{
  char_T Value[7];
};

#endif                                 /* struct_tag_fxrtQpZcildDTGvn3QeHJH */

#ifndef typedef_s_fxrtQpZcildDTGvn3QeHJH
#define typedef_s_fxrtQpZcildDTGvn3QeHJH

typedef struct tag_fxrtQpZcildDTGvn3QeHJH s_fxrtQpZcildDTGvn3QeHJH;

#endif                                 /* typedef_s_fxrtQpZcildDTGvn3QeHJH */

#ifndef struct_tag_n3SDPft8LycMqfcEsfJVBB
#define struct_tag_n3SDPft8LycMqfcEsfJVBB

struct tag_n3SDPft8LycMqfcEsfJVBB
{
  char_T f1[6];
  char_T f2[6];
  char_T f3[7];
  char_T f4[7];
  char_T f5[6];
  char_T f6[7];
};

#endif                                 /* struct_tag_n3SDPft8LycMqfcEsfJVBB */

#ifndef typedef_j_cell
#define typedef_j_cell

typedef struct tag_n3SDPft8LycMqfcEsfJVBB j_cell;

#endif                                 /* typedef_j_cell */

#ifndef struct_tag_oqflo8tPmhJ6sxPFLZiJGH
#define struct_tag_oqflo8tPmhJ6sxPFLZiJGH

struct tag_oqflo8tPmhJ6sxPFLZiJGH
{
  b_cell_wrap _data;
};

#endif                                 /* struct_tag_oqflo8tPmhJ6sxPFLZiJGH */

#ifndef typedef_s_oqflo8tPmhJ6sxPFLZiJGH
#define typedef_s_oqflo8tPmhJ6sxPFLZiJGH

typedef struct tag_oqflo8tPmhJ6sxPFLZiJGH s_oqflo8tPmhJ6sxPFLZiJGH;

#endif                                 /* typedef_s_oqflo8tPmhJ6sxPFLZiJGH */

#ifndef struct_tag_HOps0FrfA6RiWumqewPwZD
#define struct_tag_HOps0FrfA6RiWumqewPwZD

struct tag_HOps0FrfA6RiWumqewPwZD
{
  c_cell_wrap _data;
};

#endif                                 /* struct_tag_HOps0FrfA6RiWumqewPwZD */

#ifndef typedef_s_HOps0FrfA6RiWumqewPwZD
#define typedef_s_HOps0FrfA6RiWumqewPwZD

typedef struct tag_HOps0FrfA6RiWumqewPwZD s_HOps0FrfA6RiWumqewPwZD;

#endif                                 /* typedef_s_HOps0FrfA6RiWumqewPwZD */

#ifndef struct_tag_dUAff3Yz8NM29ckwbq6CH
#define struct_tag_dUAff3Yz8NM29ckwbq6CH

struct tag_dUAff3Yz8NM29ckwbq6CH
{
  cell _data;
};

#endif                                 /* struct_tag_dUAff3Yz8NM29ckwbq6CH */

#ifndef typedef_s_dUAff3Yz8NM29ckwbq6CH
#define typedef_s_dUAff3Yz8NM29ckwbq6CH

typedef struct tag_dUAff3Yz8NM29ckwbq6CH s_dUAff3Yz8NM29ckwbq6CH;

#endif                                 /* typedef_s_dUAff3Yz8NM29ckwbq6CH */

#ifndef struct_tag_7k8G96RLvhrsuJdtYxQJWF
#define struct_tag_7k8G96RLvhrsuJdtYxQJWF

struct tag_7k8G96RLvhrsuJdtYxQJWF
{
  b_cell _data;
};

#endif                                 /* struct_tag_7k8G96RLvhrsuJdtYxQJWF */

#ifndef typedef_s_7k8G96RLvhrsuJdtYxQJWF
#define typedef_s_7k8G96RLvhrsuJdtYxQJWF

typedef struct tag_7k8G96RLvhrsuJdtYxQJWF s_7k8G96RLvhrsuJdtYxQJWF;

#endif                                 /* typedef_s_7k8G96RLvhrsuJdtYxQJWF */

#ifndef struct_tag_UF0dQR13DRlcTN77hznBXH
#define struct_tag_UF0dQR13DRlcTN77hznBXH

struct tag_UF0dQR13DRlcTN77hznBXH
{
  c_cell _data;
};

#endif                                 /* struct_tag_UF0dQR13DRlcTN77hznBXH */

#ifndef typedef_s_UF0dQR13DRlcTN77hznBXH
#define typedef_s_UF0dQR13DRlcTN77hznBXH

typedef struct tag_UF0dQR13DRlcTN77hznBXH s_UF0dQR13DRlcTN77hznBXH;

#endif                                 /* typedef_s_UF0dQR13DRlcTN77hznBXH */

#ifndef struct_tag_vvSqV1w1prqiKtQKYggdIG
#define struct_tag_vvSqV1w1prqiKtQKYggdIG

struct tag_vvSqV1w1prqiKtQKYggdIG
{
  d_cell _data;
};

#endif                                 /* struct_tag_vvSqV1w1prqiKtQKYggdIG */

#ifndef typedef_s_vvSqV1w1prqiKtQKYggdIG
#define typedef_s_vvSqV1w1prqiKtQKYggdIG

typedef struct tag_vvSqV1w1prqiKtQKYggdIG s_vvSqV1w1prqiKtQKYggdIG;

#endif                                 /* typedef_s_vvSqV1w1prqiKtQKYggdIG */

#ifndef struct_tag_TnEayzHWuHj1hMPKnEr7h
#define struct_tag_TnEayzHWuHj1hMPKnEr7h

struct tag_TnEayzHWuHj1hMPKnEr7h
{
  e_cell _data;
};

#endif                                 /* struct_tag_TnEayzHWuHj1hMPKnEr7h */

#ifndef typedef_s_TnEayzHWuHj1hMPKnEr7h
#define typedef_s_TnEayzHWuHj1hMPKnEr7h

typedef struct tag_TnEayzHWuHj1hMPKnEr7h s_TnEayzHWuHj1hMPKnEr7h;

#endif                                 /* typedef_s_TnEayzHWuHj1hMPKnEr7h */

#ifndef struct_tag_lnEOVMt12CNg5nSw1iwvNF
#define struct_tag_lnEOVMt12CNg5nSw1iwvNF

struct tag_lnEOVMt12CNg5nSw1iwvNF
{
  d_cell_wrap _data;
};

#endif                                 /* struct_tag_lnEOVMt12CNg5nSw1iwvNF */

#ifndef typedef_s_lnEOVMt12CNg5nSw1iwvNF
#define typedef_s_lnEOVMt12CNg5nSw1iwvNF

typedef struct tag_lnEOVMt12CNg5nSw1iwvNF s_lnEOVMt12CNg5nSw1iwvNF;

#endif                                 /* typedef_s_lnEOVMt12CNg5nSw1iwvNF */

#ifndef struct_tag_rLqvsRnn1YgNlP4UZHEHjG
#define struct_tag_rLqvsRnn1YgNlP4UZHEHjG

struct tag_rLqvsRnn1YgNlP4UZHEHjG
{
  f_cell _data;
};

#endif                                 /* struct_tag_rLqvsRnn1YgNlP4UZHEHjG */

#ifndef typedef_s_rLqvsRnn1YgNlP4UZHEHjG
#define typedef_s_rLqvsRnn1YgNlP4UZHEHjG

typedef struct tag_rLqvsRnn1YgNlP4UZHEHjG s_rLqvsRnn1YgNlP4UZHEHjG;

#endif                                 /* typedef_s_rLqvsRnn1YgNlP4UZHEHjG */

#ifndef struct_tag_HNEgOhGwwuu4IndkThqyM
#define struct_tag_HNEgOhGwwuu4IndkThqyM

struct tag_HNEgOhGwwuu4IndkThqyM
{
  g_cell _data;
};

#endif                                 /* struct_tag_HNEgOhGwwuu4IndkThqyM */

#ifndef typedef_s_HNEgOhGwwuu4IndkThqyM
#define typedef_s_HNEgOhGwwuu4IndkThqyM

typedef struct tag_HNEgOhGwwuu4IndkThqyM s_HNEgOhGwwuu4IndkThqyM;

#endif                                 /* typedef_s_HNEgOhGwwuu4IndkThqyM */

#ifndef struct_tag_SODWYhUBKKfkB1yckYIVoG
#define struct_tag_SODWYhUBKKfkB1yckYIVoG

struct tag_SODWYhUBKKfkB1yckYIVoG
{
  h_cell _data;
};

#endif                                 /* struct_tag_SODWYhUBKKfkB1yckYIVoG */

#ifndef typedef_s_SODWYhUBKKfkB1yckYIVoG
#define typedef_s_SODWYhUBKKfkB1yckYIVoG

typedef struct tag_SODWYhUBKKfkB1yckYIVoG s_SODWYhUBKKfkB1yckYIVoG;

#endif                                 /* typedef_s_SODWYhUBKKfkB1yckYIVoG */

#ifndef struct_tag_rs0J7tUaO8r8RV5HCYwLTD
#define struct_tag_rs0J7tUaO8r8RV5HCYwLTD

struct tag_rs0J7tUaO8r8RV5HCYwLTD
{
  e_cell_wrap _data;
};

#endif                                 /* struct_tag_rs0J7tUaO8r8RV5HCYwLTD */

#ifndef typedef_s_rs0J7tUaO8r8RV5HCYwLTD
#define typedef_s_rs0J7tUaO8r8RV5HCYwLTD

typedef struct tag_rs0J7tUaO8r8RV5HCYwLTD s_rs0J7tUaO8r8RV5HCYwLTD;

#endif                                 /* typedef_s_rs0J7tUaO8r8RV5HCYwLTD */

#ifndef struct_tag_VIdiz3pTcOXEgZ6SQ4xHD
#define struct_tag_VIdiz3pTcOXEgZ6SQ4xHD

struct tag_VIdiz3pTcOXEgZ6SQ4xHD
{
  i_cell _data;
};

#endif                                 /* struct_tag_VIdiz3pTcOXEgZ6SQ4xHD */

#ifndef typedef_s_VIdiz3pTcOXEgZ6SQ4xHD
#define typedef_s_VIdiz3pTcOXEgZ6SQ4xHD

typedef struct tag_VIdiz3pTcOXEgZ6SQ4xHD s_VIdiz3pTcOXEgZ6SQ4xHD;

#endif                                 /* typedef_s_VIdiz3pTcOXEgZ6SQ4xHD */

#ifndef struct_tag_wvzWMLKjXp7EJVnnMvwbTC
#define struct_tag_wvzWMLKjXp7EJVnnMvwbTC

struct tag_wvzWMLKjXp7EJVnnMvwbTC
{
  j_cell _data;
};

#endif                                 /* struct_tag_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_s_wvzWMLKjXp7EJVnnMvwbTC
#define typedef_s_wvzWMLKjXp7EJVnnMvwbTC

typedef struct tag_wvzWMLKjXp7EJVnnMvwbTC s_wvzWMLKjXp7EJVnnMvwbTC;

#endif                                 /* typedef_s_wvzWMLKjXp7EJVnnMvwbTC */

#ifndef typedef_InstanceStruct_uI45rXB9AeVXt54lptAQyC
#define typedef_InstanceStruct_uI45rXB9AeVXt54lptAQyC

typedef struct {
  SimStruct *S;
  comm_internal_AWGNChannel sysobj;
  boolean_T sysobj_not_empty;
  uint32_T seed;
  boolean_T seed_not_empty;
  uint32_T method;
  boolean_T method_not_empty;
  uint32_T state[625];
  boolean_T state_not_empty;
  uint32_T b_state[2];
  boolean_T b_state_not_empty;
  uint32_T c_state;
  boolean_T c_state_not_empty;
  uint32_T b_method;
  boolean_T b_method_not_empty;
  uint32_T d_state[2];
  boolean_T d_state_not_empty;
  void *emlrtRootTLSGlobal;
  creal_T (*u0)[160];
  creal_T (*b_y0)[160];
} InstanceStruct_uI45rXB9AeVXt54lptAQyC;

#endif                                 /* typedef_InstanceStruct_uI45rXB9AeVXt54lptAQyC */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */

/* Function Definitions */
extern void method_dispatcher_uI45rXB9AeVXt54lptAQyC(SimStruct *S, int_T method,
  void* data);

#endif
